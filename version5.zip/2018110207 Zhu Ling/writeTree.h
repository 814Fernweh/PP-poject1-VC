typedef struct qnode Node;
typedef struct outcome Out;
void writeTree( Node *head );
void writeNode( FILE *fp, Node *node );
void printOut( FILE *fp, Node *node );
void destroyTree(Node* node);
void removeChildren(Node* parent);
