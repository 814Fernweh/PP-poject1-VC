typedef struct qnode Node;
typedef struct outcome Out;
double nodeValue( Node *node, double time );
double value( double x, double y, double time );

void setFlag(Node *node);
void makeOrRemove(Node *node,Out *times);
void setNewNodeFlag(Node *node);
void adapt(Node *head);

