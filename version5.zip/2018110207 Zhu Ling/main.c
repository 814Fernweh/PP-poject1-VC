#include "stdio.h"
#include "stdlib.h"
#include "math.h"

#include "treeStructure.h"
#include "buildTree.h"
#include "writeTree.h"
#include "nodeValue.h"

int maxlevel=6; 
int main( int argc, char **argv ) 
{
	Node *head;		// root
	
	// make the head node   level 0
	head = makeNode( 0.0,0.0, 0 );
	
	
	/* test1-1
	growTree( head ); 
	growTree( head);	
	// print the tree for Gnuplot
	writeTree( head );
	//free whole tree 
	destroyTree(head);
	head=NULL;
	*/
		
	
	/*test1-2
	growTree(head);
	makeChildren(head->child[1]);
	// print the tree for Gnuplot
	writeTree( head );
	//free whole tree 
	destroyTree(head);
	head=NULL;
	*/
	
	
	/*test2-1
	//make a full tree at level 2
	growTree( head ); 
	growTree( head);
	
	//remove children at head->child[1]
	removeChildren(head->child[1]);
	// print the tree for Gnuplot
	writeTree( head );
	//free whole tree 
	destroyTree(head);
	head=NULL;
	*/
	

	
	/*
	//	test2-2
	//create a tree
	growTree(head);
	makeChildren(head->child[0]);
	makeChildren(head->child[3]);
	// remove children at head->child[0]
	removeChildren(head->child[0]);
	// print the tree for Gnuplot
	writeTree( head );
	//free whole tree 
	destroyTree(head);
	head=NULL;
	*/
	
	
	 
    //test3	
    // create a full quadtree at level 3
	growTree(head);  
	growTree(head); 
	growTree(head); 
	// test task 3 extended: continues running the Task 3 algorithm until the tree does not change
	adapt(head);

	// print the tree for Gnuplot
	writeTree( head );
	//free whole tree 
	destroyTree(head);
	head=NULL;
  return 0;
}  




