#include "stdio.h"
#include "stdlib.h"
#include "math.h"

#include "treeStructure.h"
#include "buildTree.h"
#include "writeTree.h"
	
int main( int argc, char **argv ) 
{
	
	Node *head;//���ڵ� 
	// make the head node   level 0
	head = makeNode( 0.0,0.0, 0 );

	
	/*	test1-1
	makeChildren( head ); 
	growTree( head);	
	destroyTree(head);
	*/	
	
	/*	test1-2
	growTree(head);
	makeChildren(head->child[1]);
	destroyTree(head);
	*/
	
	
	/*	test2-1
	//make a full tree at level 2
	makeChildren( head ); 
	growTree( head);
	//remove children at head->child[1]
	removeChildren(head->child[1]);
	//free whole tree using task1
	destroyTree(head);
	*/
	
	
	//test2-2
	//create a tree
	growTree(head);
	makeChildren(head->child[0]);
	makeChildren(head->child[3]);
	// remove children at head->child[0]
	removeChildren(head->child[0]);
	//free whole tree using task1
	destroyTree(head);	

	// print the tree for Gnuplot
	writeTree( head );

  return 0;
}  




