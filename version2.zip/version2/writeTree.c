#include "stdio.h"
#include "stdlib.h"
#include "math.h"
#include "writeTree.h"
#include "treeStructure.h"

void writeTree( Node *head ) 
{

  FILE *fp = fopen("quad.out","w");

  writeNode(fp,head); //  ��head��ʼ 

  fclose(fp);

  return;
}

void writeNode( FILE *fp, Node *node ) 
{

  int i;

  if( node->child[0] == NULL )
    printOut( fp, node );
  else {
    for ( i=0; i<4; ++i ) {
      writeNode( fp, node->child[i] );
    }
  }
  return;
}

// write out the (x,y) corners of the node    

void printOut( FILE *fp, Node *node ) 
{
  double x = node->xy[0];
  double y = node->xy[1];
  int level = node->level;
  double h = pow(2.0,-level);
  
  fprintf(fp, " %g %g\n",x,y);
  fprintf(fp, " %g %g\n",x+h,y);
  fprintf(fp, " %g %g\n",x+h,y+h);
  fprintf(fp, " %g %g\n",x,y+h);
  fprintf(fp, " %g %g\n\n",x,y);
  return;
}

// free all allocated memory
void destroyTree(Node* node)
{
	int i;
	Node* chNode;	//create a child node	
	//Traverse the nodes
	for(i=0;i<4;++i)
	{
		chNode=node->child[i];		
		// free the node if it is a  leaf node
		if(chNode->child[0]== NULL)
		{
			free((void*)chNode);
		}
		//if it is not a leaf node, continue to check its children
		else
		{
			destroyTree(chNode);
		}
	 }
	 //free the root
	 free((void*)node);
	 return; 
}


//remove the 4 children from a given node and free the memory
void removeChildren(Node* parent)
{
	int i;
	Node* chNode;	//create a child node
	
	//free all 4 children memory of the given node parent
	for (i=0;i<4;++i)
	{
		chNode=parent->child[i];
		free((void*)chNode); 
		//resets the parent node data	 
		parent->child[i]=NULL; 
	}
	return ;
}

