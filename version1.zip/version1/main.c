#include "stdio.h"
#include "stdlib.h"
#include "math.h"

#include "treeStructure.h"
#include "buildTree.h"
#include "writeTree.h"
	
int main( int argc, char **argv ) 
{
	

  Node *head;//���ڵ� 
  // make the head node   level 0
  head = makeNode( 0.0,0.0, 0 );

	
	//project1  test1-1
	makeChildren( head ); 
	growTree( head);
	destroyTree(head);
	
	
	/*test1-2
	growTree(head);
	makeChildren(head->child[1]);
	destroyTree(head);
	*/

	
  // print the tree for Gnuplot
	writeTree( head );

  return 0;
}  




