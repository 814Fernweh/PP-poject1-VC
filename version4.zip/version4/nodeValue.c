#include "stdio.h"
#include "stdlib.h"
#include "math.h"
#include "nodeValue.h"
#include "treeStructure.h"

// Evaluate function at centre of quadtree node
double nodeValue( Node *node, double time ) {

  int level = node->level;
  double x = node->xy[0];
  double y = node->xy[1];

  double h = pow(2.0,-level);

  return( value( x+0.5*h, y+0.5*h, time ) );
}

// Data function
double value( double x, double y, double time ) {

  return( 2.0*exp(-8.0*(x-time)*(x-time)) - 1.0 ) ;
}

// set flag value to decide if it needs to add or remove children
void setFlag(Node *node)
{     
	int i;
	//when the node is a leaf node
	if(node->child[0]==NULL)
  	{
  		double val;
  		double time=0.0;
  		val=nodeValue( node, time );
  		
  		// determine the flag value according to the 'value' function
  		if(val>0.5)
  		{
  			node->flag=1;
		}
		if(val<-0.5)
		{
			node->flag=-1;
		}
	}
	
	//when the node is not a leaf node
	else
	{
		//all nodes which are not leaf nodes should be set to flag=0
		node->flag=0;
		//for the node's children, continue to call setflag function to determine the flag value
		for(i=0;i<4;++i)
		{
			setFlag(node->child[i]);
		}		
	}
	return;	
}
  
//decide if the node needs to add or remove children according to the flag
void makeOrRemove(Node *node,Out *times,int maxlevel) 
{
	//times->add=0;
	//times->remove=0;
	
	//when the node is a leaf node,continue to check its flag
	if(node->child[0]==NULL)   
	{
		//when the flag is 1 and the node level is less than maxlevel, it can add children
		if(node->flag==1 && node->level<maxlevel)
		{
			makeChildren( node );
			//after makechidren, 'node' becomes a parent node, its flag should be 0
			node->flag=0;
			//record the add times			
			times->add+=4;
		}					
	}
	
	//when the node is not a leaf node
	else              
	{	
		
		Node *ch0=node->child[0];
		Node *ch1=node->child[1];
		Node *ch2=node->child[2];
		Node *ch3=node->child[3];
		//if its all 4 children are leaf nodes
		if (ch0->child[0]==NULL && ch1->child[0]==NULL&& ch2->child[0]==NULL && ch3->child[0]==NULL ) 
		{
			//if its all 4 children have flag=-1, then remove its children
			if(ch0->flag==-1 && ch1->flag==-1 && ch2->flag==-1 && ch3->flag==-1)
			{
				removeChildren(node);				
				//after remove children, the node flag should be 0, 
				//otherwise it will remove or add childen without break
				node->flag=0;
				//record the remove times
				times->remove+=4;	
			}
			
			//if not all its 4 leaf children have flag=-1
			else
			{
				int i;
				for(i=0;i<4;i++)
				{
					Node *chNode=node->child[i];
					//when the flag is 1 and the node level is less than maxlevel, it can add children
					if(chNode->flag==1  && chNode->level<maxlevel) 
					{
						makeChildren( chNode );					
						//after makechidren, 'node' becomes a parent node, its flag should be 0
						chNode->flag=0;	
						//record the add times		
						times->add+=4;
					}
				}
			}						
		}
		//when not its all 4 children are leaf nodes, coninue to call makeOrRemove function
		else
		{
			int j;
			for(j=0;j<4;++j)
			{
				makeOrRemove(node->child[j],times,maxlevel);
			}	
		}			
	}
	return;  
}

//use adapt function to continuously run the Task 3 algorithm until the tree does not change
void adapt(Node *head)
{
	Out t;
	t.add=0;
	t.remove=0;
	//need to set a maximum level to prevent nodes always being added
	//set the maxlevel to 6
	int maxlevel=6;
    makeOrRemove(head,&t,maxlevel); 
	printf("add: %d, remove: %d\n",t.add,t.remove); 
	//when 0 nodes added and 0 nodes removed, stop to run
	while(t.add>0 || t.remove>0)  
	{
		Out t1;
		t1.add=0;
		t1.remove=0;		
		makeOrRemove(head,&t1,maxlevel);
		printf("add: %d, remove: %d\n",t1.add,t1.remove);
		t=t1;
	}
	
	
	return;
}


// assign flag values to new nodes which are added by calling  makeChildren function
void setNewNodeFlag(Node *node)
{
	double v;
  	double ti=0.0;
  	v=nodeValue( node, ti );
  	if(v>0.5)
  	{
  		node->flag=1;
	}
	if(v<-0.5)
	{
		node->flag=-1;
	}
	return;	
 } 


