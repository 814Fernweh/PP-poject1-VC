#include "stdio.h"
#include "stdlib.h"
#include "math.h"
#include "buildTree.h"
#include "treeStructure.h"
#include "nodeValue.h"

Node *makeNode( double x, double y, int level ) {
	
  int i;
  Node *node = (Node *)malloc(sizeof(Node));
  //initialse 
  memset(node,0x00,sizeof(Node));
  
//set the node data 
  node->level = level;
  node->xy[0] = x;
  node->xy[1] = y;
  setNewNodeFlag(node);

  for( i=0;i<4;++i )
    node->child[i] = NULL;
    
  return node;  // Function returns a pointer to the new Node
}

void makeChildren( Node *parent )
 {

  double x = parent->xy[0]; 
  double y = parent->xy[1];

  int level = parent->level;

  double hChild = pow(2.0,-(level+1));

  parent->child[0] = makeNode( x,y, level+1 );  
  parent->child[1] = makeNode( x+hChild,y, level+1 );
  parent->child[2] = makeNode( x+hChild,y+hChild, level+1 );
  parent->child[3] = makeNode( x,y+hChild, level+1 );

  return;  
}
void growTree(Node *node)
{
  int j;
  	if(node->child[0] == NULL )  
  	{
		makeChildren(node);
	}	
  	else
  	{
  		for(j=0;j<4;++j)
		 {
		  	growTree(node->child[j]);
		 }
		   
}
  return;  
}

 
 
 
 
 
 

