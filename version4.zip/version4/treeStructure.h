struct qnode {
  int level;
  double xy[2];
  struct qnode *child[4];
  int flag;
};

struct outcome{
	int add;
	int remove;
};

