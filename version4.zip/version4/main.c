#include "stdio.h"
#include "stdlib.h"
#include "math.h"

#include "treeStructure.h"
#include "buildTree.h"
#include "writeTree.h"
#include "nodeValue.h"

int main( int argc, char **argv ) 
{
	Node *head;		// root
	
	// make the head node   level 0
	head = makeNode( 0.0,0.0, 0 );
	
	
	/* project1  test1-1
	makeChildren( head ); 
	growTree( head);	
	// print the tree for Gnuplot
	writeTree( head );
	//free whole tree 
	destroyTree(head);
	head=NULL;
	*/
		
	
	/*test1-2
	growTree(head);
	makeChildren(head->child[1]);
	// print the tree for Gnuplot
	writeTree( head );
	//free whole tree 
	destroyTree(head);
	head=NULL;
	*/
	
	
	/*test2-1
	//make a full tree at level 2
	makeChildren( head ); 
	growTree( head);
	//remove children at head->child[1]
	removeChildren(head->child[1]);
	// print the tree for Gnuplot
	writeTree( head );
	//free whole tree 
	destroyTree(head);
	head=NULL;
	*/
	

	
	/*
	//	test2-2
	//create a tree
	growTree(head);
	makeChildren(head->child[0]);
	makeChildren(head->child[3]);
	// remove children at head->child[0]
	removeChildren(head->child[0]);
	// print the tree for Gnuplot
	writeTree( head );
	//free whole tree 
	destroyTree(head);
	head=NULL;
	*/
	
	
	/* 
    //test3	
    // create a full quadtree at level 3
	growTree(head);  
	growTree(head); 
	growTree(head); 

	*/
	
	/* test 3
	//add or remove children of the node according to the flag value
	setFlag(head);
	Out t;
	t.add=0;
	t.remove=0;
	int maxlevel=6;
    makeOrRemove(head,&t,maxlevel);     
    printf("%d  %d",t.add,t.remove); 
    */

	
	
	// test task 3 extended: continues running the Task 3 algorithm until the tree does not change
	adapt(head);

	// print the tree for Gnuplot
	writeTree( head );
	//free whole tree 
	destroyTree(head);
	head=NULL;
  return 0;
}  




